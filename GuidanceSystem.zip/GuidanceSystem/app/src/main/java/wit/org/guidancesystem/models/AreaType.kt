package wit.org.guidancesystem.models

enum class AreaType {
    ROOM, DOOR, CORRIDOR, WALL, DANGER
}